#include <stdio.h>
//..

void* producteur(void* pid) {
    // ...
    return NULL;
}

void* consommateur(void* cid) {
    // ...

    return NULL;
}
// ...

int main(int argc, char* argv[]) {
    // Les paramètres du programme sont, dans l'ordre :
    // le nombre de producteurs, le nombre de consommateurs
    // et la taille du tampon.

    // ..
    return 0;
}
