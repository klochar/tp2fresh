// Ajouter les directives d'inclusion nécessaires

int main() {
    
}
